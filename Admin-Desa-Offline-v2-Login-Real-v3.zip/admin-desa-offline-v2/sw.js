const CACHE="admin-desa-v5-login-real-auth";
const ASSETS=["./","./index.html","./css/style.css","./js/database.js","./js/app.js","./js/customers.js","./js/import.js","./js/payments.js","./js/receipt.js","./js/profile.js","./manifest.json","./assets/icon.svg"];
self.addEventListener("install",e=>e.waitUntil(caches.open(CACHE).then(c=>c.addAll(ASSETS)).then(()=>self.skipWaiting())));
self.addEventListener("activate",e=>e.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(k=>k!==CACHE).map(k=>caches.delete(k)))).then(()=>self.clients.claim())));
self.addEventListener("fetch",e=>e.respondWith(caches.match(e.request).then(r=>r||fetch(e.request))));
