/* Offline bulk customer import: JSON + XLSX (no internet required). */
function openBulkImport(){
  showModal(`<div class="modal-icon">⇧</div><h3>Tambah Pelanggan Massal</h3>
    <p>Impor banyak pelanggan sekaligus dari file <b>Excel (.xlsx)</b> atau <b>JSON (.json)</b>. Data diproses sepenuhnya di perangkat ini.</p>
    <div class="import-drop" id="importDrop">
      <div class="import-file-icon">▤</div>
      <b>Pilih file</b><small>Excel .xlsx atau JSON .json</small>
      <input id="bulkFile" type="file" accept=".xlsx,.json,application/json,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet">
    </div>
    <div class="import-help"><b>Kolom Excel/JSON:</b><br>Nama · ID Pelanggan · Alias · Jenis Layanan · Nominal Tagihan · Status (opsional) · Tanggal Lunas (opsional)</div>
    <div class="modal-actions"><button class="btn btn-secondary" onclick="closeModal()">Batal</button><button class="btn btn-primary" onclick="downloadJSONTemplate()">Template JSON</button></div>`);
  const drop=document.getElementById('importDrop'), input=document.getElementById('bulkFile');
  drop.onclick=()=>input.click();
  input.addEventListener('click',e=>e.stopPropagation());
  input.onchange=()=>{ if(input.files[0]) previewBulkFile(input.files[0]); };
  ['dragenter','dragover'].forEach(ev=>drop.addEventListener(ev,e=>{e.preventDefault();drop.classList.add('drag');}));
  ['dragleave','drop'].forEach(ev=>drop.addEventListener(ev,e=>{e.preventDefault();drop.classList.remove('drag');}));
  drop.addEventListener('drop',e=>{const f=e.dataTransfer.files[0];if(f){input.files=e.dataTransfer.files;previewBulkFile(f);}});
}

async function previewBulkFile(file){
  try{
    const rows=await readImportFile(file);
    if(!rows.length) throw new Error('File tidak berisi data pelanggan.');
    const normalized=normalizeImportedRows(rows);
    const valid=normalized.filter(x=>x.ok).map(x=>x.data);
    const invalid=normalized.filter(x=>!x.ok);
    const dupInFile=new Set(); let duplicate=0;
    valid.forEach(x=>{if(dupInFile.has(x.meter))duplicate++;else dupInFile.add(x.meter);});
    showModal(`<div class="modal-icon" style="background:#e9f8f1;color:#10a875">✓</div><h3>Pratinjau Impor</h3>
      <p>File <b>${esc(file.name)}</b> siap diproses.</p>
      <div class="import-summary">
        <div><b>${valid.length}</b><span>Baris valid</span></div>
        <div><b>${invalid.length}</b><span>Baris bermasalah</span></div>
        <div><b>${duplicate}</b><span>Duplikat file</span></div>
      </div>
      ${invalid.length?`<div class="import-errors"><b>Contoh masalah:</b>${invalid.slice(0,5).map(x=>`<div>Baris ${x.row}: ${esc(x.error)}</div>`).join('')}</div>`:''}
      <div class="import-help">ID Pelanggan yang sudah ada pada layanan yang sama akan <b>dilewati</b>, bukan ditimpa.</div>
      <div class="modal-actions"><button class="btn btn-secondary" onclick="openBulkImport()">Pilih Lagi</button><button class="btn btn-primary" onclick='commitBulkImport(${JSON.stringify(valid).replace(/</g,'\\u003c')})'>Import ${valid.length} Data</button></div>`);
  }catch(e){showModal(`<div class="modal-icon" style="background:#ffe3e3;color:#e74b4b">!</div><h3>File Tidak Bisa Dibaca</h3><p>${esc(e.message||'Format file tidak sesuai.')}</p><div class="modal-actions"><button class="btn btn-primary" onclick="openBulkImport()">Coba Lagi</button></div>`);}
}

async function readImportFile(file){
  const name=file.name.toLowerCase();
  if(name.endsWith('.json')){
    const text=await file.text();
    const data=JSON.parse(text);
    if(Array.isArray(data)) return data;
    if(Array.isArray(data.customers)) return data.customers;
    throw new Error('JSON harus berupa array pelanggan atau objek yang memiliki properti "customers".');
  }
  if(name.endsWith('.xlsx')) return readXLSXFile(file);
  throw new Error('Format belum didukung. Gunakan .xlsx atau .json.');
}

async function readXLSXFile(file){
  const ab=await file.arrayBuffer();
  const zip=new SimpleZip(ab);
  const workbook=await zip.text('xl/workbook.xml');
  const rels=await zip.text('xl/_rels/workbook.xml.rels');
  if(!workbook) throw new Error('File XLSX tidak valid: workbook.xml tidak ditemukan.');
  const doc=new DOMParser().parseFromString(workbook,'application/xml');
  const relDoc=new DOMParser().parseFromString(rels||'','application/xml');
  const sheet=doc.getElementsByTagNameNS('*','sheet')[0];
  if(!sheet) throw new Error('Sheet Excel tidak ditemukan.');
  const rid=sheet.getAttribute('r:id');
  let target='worksheets/sheet1.xml';
  const relNodes=relDoc.getElementsByTagNameNS('*','Relationship');
  for(const r of relNodes){if(r.getAttribute('Id')===rid){target=r.getAttribute('Target');break;}}
  target=target.replace(/^\//,'').replace(/^xl\//,'');
  if(!target.startsWith('xl/')) target='xl/'+target;
  const shared=[];
  const sst=await zip.text('xl/sharedStrings.xml');
  if(sst){const sd=new DOMParser().parseFromString(sst,'application/xml');for(const si of sd.getElementsByTagNameNS('*','si')){let out='';for(const t of si.getElementsByTagNameNS('*','t'))out+=t.textContent||'';shared.push(out);}}
  const sheetXml=await zip.text(target); if(!sheetXml) throw new Error('Sheet pertama tidak dapat dibaca.');
  const sd=new DOMParser().parseFromString(sheetXml,'application/xml');
  const rows=[];
  for(const row of sd.getElementsByTagNameNS('*','row')){
    const cells={};
    for(const cell of row.getElementsByTagNameNS('*','c')){
      const ref=cell.getAttribute('r')||''; const col=ref.replace(/[0-9]/g,'');
      const type=cell.getAttribute('t'); const v=cell.getElementsByTagNameNS('*','v')[0];
      let val=v?v.textContent:'';
      if(type==='s') val=shared[Number(val)]??'';
      else if(type==='inlineStr'){let txt='';for(const t of cell.getElementsByTagNameNS('*','t'))txt+=t.textContent||'';val=txt;}
      cells[col]=val;
    }
    rows.push(cells);
  }
  if(!rows.length)return [];
  const headers=Object.keys(rows[0]);
  return rows.slice(1).map(r=>{const o={};headers.forEach(h=>o[h]=r[h]??'');return o;});
}

class SimpleZip{
  constructor(ab){this.u8=new Uint8Array(ab);this.view=new DataView(ab);this.entries=this.parse();}
  parse(){
    const u=this.u8;let p=-1;for(let i=u.length-22;i>=Math.max(0,u.length-65558);i--){if(u[i]===0x50&&u[i+1]===0x4b&&u[i+2]===0x05&&u[i+3]===0x06){p=i;break;}}
    if(p<0)throw new Error('File bukan ZIP/XLSX yang valid.');
    const total=this.view.getUint16(p+10,true),cdSize=this.view.getUint32(p+12,true),cdOffset=this.view.getUint32(p+16,true);let pos=cdOffset;const out={};
    for(let n=0;n<total;n++){if(this.view.getUint32(pos,true)!==0x02014b50)throw new Error('Struktur XLSX rusak.');const method=this.view.getUint16(pos+10,true),csize=this.view.getUint32(pos+20,true),usize=this.view.getUint32(pos+24,true),nameLen=this.view.getUint16(pos+28,true),extraLen=this.view.getUint16(pos+30,true),commentLen=this.view.getUint16(pos+32,true),localOffset=this.view.getUint32(pos+42,true);const name=new TextDecoder().decode(u.slice(pos+46,pos+46+nameLen));out[name]={method,csize,usize,localOffset};pos+=46+nameLen+extraLen+commentLen;}
    return out;
  }
  async bytes(name){const e=this.entries[name];if(!e)return null;const p=e.localOffset;if(this.view.getUint32(p,true)!==0x04034b50)throw new Error('ZIP entry rusak: '+name);const nl=this.view.getUint16(p+26,true),el=this.view.getUint16(p+28,true);const data=this.u8.slice(p+30+nl+el,p+30+nl+el+e.csize);if(e.method===0)return data;if(e.method===8){if(!('DecompressionStream' in window))throw new Error('Browser ini belum mendukung pembacaan XLSX offline. Gunakan Chrome/Edge versi terbaru.');const ds=new DecompressionStream('deflate-raw');const stream=new Blob([data]).stream().pipeThrough(ds);return new Uint8Array(await new Response(stream).arrayBuffer());}throw new Error('Metode kompresi XLSX belum didukung.');}
  async text(name){const b=await this.bytes(name);return b?new TextDecoder('utf-8').decode(b):null;}
}

function normalizeImportedRows(rows){
  const aliases={
    name:['nama','name','nama pelanggan','customer','customer name'],
    meter:['id pelanggan','id_pelanggan','idpelanggan','customer id','customer_id','id meter','id_meter','meter','meter id','nomor meter','no meter'],
    alias:['alias','keterangan','alamat','nama alias'],
    service:['jenis layanan','jenis tagihan','layanan','service','kategori','kategori tagihan'],
    amount:['nominal tagihan','nominal','tagihan','jumlah','amount','tarif'],
    status:['status','status pembayaran'],
    paidAt:['tanggal lunas','tanggal pembayaran','paidat','paid_at','paid date']
  };
  function get(o,keys){const map={};Object.keys(o).forEach(k=>map[String(k).trim().toLowerCase()]=o[k]);for(const k of keys)if(map[k]!==undefined)return map[k];return '';}
  return rows.map((r,i)=>{
    const name=String(get(r,aliases.name)||'').trim();
    const meter=String(get(r,aliases.meter)||'').trim();
    const alias=String(get(r,aliases.alias)||'').trim();
    const service=String(get(r,aliases.service)||'Listrik').trim()||'Listrik';
    const amount=parseAmount(get(r,aliases.amount));
    const statusRaw=String(get(r,aliases.status)||'').trim().toLowerCase();
    const status=['lunas','paid','sudah lunas','terbayar'].includes(statusRaw)?'paid':'unpaid';
    const paidRaw=get(r,aliases.paidAt); let paidAt=null;
    if(paidRaw){const d=new Date(paidRaw);if(!Number.isNaN(d.getTime()))paidAt=d.toISOString();}
    if(status==='paid'&&!paidAt)paidAt=new Date().toISOString();
    if(!name)return {row:i+2,ok:false,error:'Nama kosong.'};
    if(!meter)return {row:i+2,ok:false,error:'ID Pelanggan kosong.'};
    if(!amount || amount<0)return {row:i+2,ok:false,error:'Nominal tagihan tidak valid.'};
    return {row:i+2,ok:true,data:{id:uid('c'),name,meter,alias,service,amount,status,paidAt}};
  });
}
function parseAmount(v){
  if(typeof v==='number')return v;
  let s=String(v??'').trim();if(!s)return 0;
  s=s.replace(/rp/gi,'').replace(/\s/g,'');
  if(/^[0-9]+([.,][0-9]{3})+$/.test(s))s=s.replace(/[.,]/g,'');
  else if(/^[0-9]+,[0-9]{1,2}$/.test(s))s=s.replace(',','.');
  else s=s.replace(/\./g,'').replace(',','.');
  const n=Number(s);return Number.isFinite(n)?n:0;
}
function commitBulkImport(items){
  const existing=new Set(DB.customers.map(c=>serviceName(c)+'|'+String(c.meter).trim()));let added=0,skipped=0;
  items.forEach(c=>{const key=serviceName(c)+'|'+c.meter;if(existing.has(key)){skipped++;return;}DB.customers.push(c);existing.add(key);added++;});
  saveDB();closeModal();toast(`Impor selesai: ${added} ditambahkan${skipped?`, ${skipped} duplikat dilewati`:''}.`);navigate('customers');
}
function downloadJSONTemplate(){
  const sample=[{nama:'Budi Santoso',id_pelanggan:'12345678901',alias:'Rumah Budi',jenis_layanan:'Listrik',nominal_tagihan:150000,status:'belum',tanggal_lunas:''},{nama:'Siti Aminah',id_pelanggan:'WIFI-02',alias:'',jenis_layanan:'WiFi RT/RW Net',nominal_tagihan:200000,status:'lunas',tanggal_lunas:'2026-08-28'}];
  const blob=new Blob([JSON.stringify(sample,null,2)],{type:'application/json'});const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download='template-pelanggan.json';a.click();setTimeout(()=>URL.revokeObjectURL(a.href),500);toast('Template JSON dibuat.');
}
