const DB_KEY = "adminDesaDB_v1";

const defaultDB = {
  profile: {
    adminName: "Admin Desa",
    email: "",
    desa: "",
    kecamatan: "",
    kabupaten: "",
    provinsi: ""
  },
  customers: [],
  receipts: []
};

function loadDB(){
  try{
    const raw = localStorage.getItem(DB_KEY);
    if(!raw){ localStorage.setItem(DB_KEY, JSON.stringify(defaultDB)); return structuredClone(defaultDB); }
    return JSON.parse(raw);
  }catch(e){ return structuredClone(defaultDB); }
}
let DB = loadDB();

function saveDB(){ localStorage.setItem(DB_KEY, JSON.stringify(DB)); }

function uid(prefix="id"){ return prefix+"_"+Date.now().toString(36)+"_"+Math.random().toString(36).slice(2,7); }
function rupiah(n){ return new Intl.NumberFormat("id-ID",{style:"currency",currency:"IDR",maximumFractionDigits:0}).format(Number(n)||0); }
function dateID(iso){
  if(!iso) return "-";
  return new Intl.DateTimeFormat("id-ID",{day:"2-digit",month:"long",year:"numeric"}).format(new Date(iso));
}
function timeID(iso){
  if(!iso) return "-";
  return new Intl.DateTimeFormat("id-ID",{hour:"2-digit",minute:"2-digit"}).format(new Date(iso))+" WIB";
}
const SERVICE_OPTIONS=["Listrik","WiFi RT/RW Net","PAM / Air Swadaya","Iuran Sampah","Dana Sosial","Iuran Warga","Lainnya"];
function serviceName(c){return String(c?.service||"Listrik").trim()||"Listrik";}
function idLabel(c){return "ID Pelanggan";}
function esc(s){
  return String(s??"").replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[m]));
}
