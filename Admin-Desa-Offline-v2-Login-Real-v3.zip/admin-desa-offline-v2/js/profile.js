function renderProfile(){
  const p=DB.profile;
  screen.innerHTML=`<div class="page">
    <section class="profile-head">
      <div class="avatar">👤</div><h2>${esc(p.adminName)}</h2><p>Administrator</p><p>${esc(p.email)}</p>
    </section>
    <section class="section"><div class="section-title"><h3>Informasi Desa</h3><button onclick="editProfile()">Edit</button></div>
      <div class="info-list">
        <div class="info-row"><span>Nama Desa</span><b>${esc(p.desa)}</b></div>
        <div class="info-row"><span>Kecamatan</span><b>${esc(p.kecamatan)}</b></div>
        <div class="info-row"><span>Kabupaten</span><b>${esc(p.kabupaten)}</b></div>
        <div class="info-row"><span>Provinsi</span><b>${esc(p.provinsi)}</b></div>
      </div>
    </section>
    <section class="section developer-card">
      <div class="developer-badge">⌨</div><div class="developer-kicker">Developer</div><h3>Anz-Media</h3>
      <div class="developer-contact"><div><span>☎</span><a href="tel:081280416515">0812-8041-6515</a></div><div><span>✉️</span><a href="mailto:satria.ebc@gmail.com">satria.ebc@gmail.com</a></div></div>
    </section>
    <section class="section"><button class="btn btn-danger btn-full" onclick="logoutConfirm()">⇥ Logout</button></section>
    <section class="section">
      <div class="section-title"><h3>Backup & Ekspor Data</h3></div>
      <p style="font-size:10px;color:var(--muted);line-height:1.7">Simpan seluruh data aplikasi ke file JSON untuk backup lengkap, atau ekspor data pelanggan dan transaksi ke file Excel (.xlsx) yang rapi dan dapat dibuka langsung di Microsoft Excel, WPS Office, dan aplikasi spreadsheet lainnya.</p>
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-top:10px">
        <button class="btn btn-primary" onclick="exportData()">⬇ Backup JSON</button>
        <button class="btn btn-secondary" onclick="exportExcel()">📊 Ekspor Excel</button>
      </div>
      <button class="btn btn-secondary btn-full" style="margin-top:8px" onclick="resetData()">↻ Reset Data</button>
    </section>
  </div>`;
}
function editProfile(){
  const p=DB.profile;
  showModal(`<h3 style="margin-bottom:15px">Edit Profil Desa</h3><div class="field"><label>Nama Admin</label><input id="pAdmin" value="${esc(p.adminName)}"></div><div class="field"><label>Email</label><input id="pEmail" value="${esc(p.email)}"></div><div class="field"><label>Nama Desa</label><input id="pDesa" value="${esc(p.desa)}"></div><div class="field"><label>Kecamatan</label><input id="pKec" value="${esc(p.kecamatan)}"></div><div class="field"><label>Kabupaten</label><input id="pKab" value="${esc(p.kabupaten)}"></div><div class="field"><label>Provinsi</label><input id="pProv" value="${esc(p.provinsi)}"></div><div class="modal-actions"><button class="btn btn-secondary" onclick="closeModal()">Batal</button><button class="btn btn-primary" onclick="saveProfile()">Simpan</button></div>`);
}
function saveProfile(){
  Object.assign(DB.profile,{adminName:pAdmin.value.trim()||"Satrianto",email:pEmail.value.trim()||"satria.ebc@gmail.com",desa:pDesa.value.trim()||"Kedunggandu Wonotolo",kecamatan:pKec.value.trim()||"Gondang",kabupaten:pKab.value.trim()||"Sragen",provinsi:pProv.value.trim()||"Jawa Tengah"});
  saveDB();closeModal();toast("Profil berhasil diperbarui.");renderProfile();
}
function logoutConfirm(){showModal(`<div class="modal-icon" style="background:#ffe3e3;color:#e74b4b">!</div><h3>Logout</h3><p>Sesi login akan diakhiri dan aplikasi dikunci kembali.</p><div class="modal-actions"><button class="btn btn-secondary" onclick="closeModal()">Batal</button><button class="btn btn-danger" onclick="performLogout()">Logout</button></div>`);}
function performLogout(){closeModal();if(window.AdminAuth){window.AdminAuth.logout();}else{location.reload();}}
function fileStamp(){const d=new Date();return d.getFullYear()+String(d.getMonth()+1).padStart(2,"0")+String(d.getDate()).padStart(2,"0")+"-"+String(d.getHours()).padStart(2,"0")+String(d.getMinutes()).padStart(2,"0");}
function downloadBlob(blob,name){const a=document.createElement("a");const url=URL.createObjectURL(blob);a.href=url;a.download=name;document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),1000);}
function exportData(){
  // Backup JSON dibuat dengan struktur yang sama persis dengan JSON Import Massal.
  // Hanya data pelanggan yang diekspor; metadata aplikasi, profil, receipts, dll. tidak ikut.
  const backup=DB.customers.map(c=>({
    "Nama":String(c?.name??""),
    "ID Pelanggan":String(c?.meter??""),
    "Alias":String(c?.alias??""),
    "Jenis Layanan":serviceName(c),
    "Nominal Tagihan":Number(c?.amount)||0,
    "Status":c?.status==='paid'?"Lunas":"Belum Lunas",
    "Tanggal Lunas":c?.paidAt?new Date(c.paidAt).toLocaleString('id-ID'):""
  }));
  downloadBlob(new Blob([JSON.stringify(backup,null,2)],{type:"application/json;charset=utf-8"}),"backup-admin-desa-"+fileStamp()+".json");
  toast("Backup JSON berhasil dibuat.");
}
function xmlEsc(v){return String(v??'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&apos;');}
function excelCol(n){let s='';while(n>=0){s=String.fromCharCode(65+(n%26))+s;n=Math.floor(n/26)-1;}return s;}
function crc32(bytes){let c=0xffffffff;for(let i=0;i<bytes.length;i++){c^=bytes[i];for(let k=0;k<8;k++)c=(c>>>1)^((c&1)?0xedb88320:0);}return(c^0xffffffff)>>>0;}
function makeZip(files){
  const enc=new TextEncoder(), parts=[], central=[]; let offset=0;
  for(const [name,content] of files){
    const nb=enc.encode(name), data=content instanceof Uint8Array?content:enc.encode(content), crc=crc32(data);
    const local=new Uint8Array(30+nb.length+data.length), dv=new DataView(local.buffer);
    dv.setUint32(0,0x04034b50,true);dv.setUint16(4,20,true);dv.setUint16(6,0,true);dv.setUint16(8,0,true);dv.setUint32(14,crc,true);dv.setUint32(18,data.length,true);dv.setUint32(22,data.length,true);dv.setUint16(26,nb.length,true);dv.setUint16(28,0,true);local.set(nb,30);local.set(data,30+nb.length);parts.push(local);
    const cd=new Uint8Array(46+nb.length), cv=new DataView(cd.buffer);cv.setUint32(0,0x02014b50,true);cv.setUint16(4,20,true);cv.setUint16(6,20,true);cv.setUint16(8,0,true);cv.setUint16(10,0,true);cv.setUint32(16,crc,true);cv.setUint32(20,data.length,true);cv.setUint32(24,data.length,true);cv.setUint16(28,nb.length,true);cv.setUint16(30,0,true);cv.setUint16(32,0,true);cv.setUint16(34,0,true);cv.setUint32(38,0,true);cv.setUint32(42,offset,true);cd.set(nb,46);central.push(cd);offset+=local.length;
  }
  const centralSize=central.reduce((a,b)=>a+b.length,0), end=new Uint8Array(22), ev=new DataView(end.buffer);ev.setUint32(0,0x06054b50,true);ev.setUint16(4,0,true);ev.setUint16(6,0,true);ev.setUint16(8,files.length,true);ev.setUint16(10,files.length,true);ev.setUint32(12,centralSize,true);ev.setUint32(16,offset,true);ev.setUint16(20,0,true);
  return new Blob([...parts,...central,end],{type:'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'});
}
function buildCustomerXLSX(){
  // Struktur ini sengaja sama persis dengan kolom Impor Massal Pelanggan.
  const headers=['Nama','ID Pelanggan','Alias','Jenis Layanan','Nominal Tagihan','Status','Tanggal Lunas'];
  const rows=DB.customers.map(c=>[
    c.name||'',c.meter||'',c.alias||'',serviceName(c),Number(c.amount)||0,
    c.status==='paid'?'Lunas':'Belum Lunas',c.paidAt?new Date(c.paidAt).toLocaleString('id-ID'):''
  ]);
  const all=[headers,...rows];
  const widths=[28,20,24,24,20,16,24];
  const rowXml=all.map((row,r)=>`<row r="${r+1}">${row.map((v,c)=>{
    const ref=excelCol(c)+(r+1), style=r===0?1:(c===4?2:0);
    if(typeof v==='number')return `<c r="${ref}" s="${style}"><v>${v}</v></c>`;
    return `<c r="${ref}" s="${style}" t="inlineStr"><is><t xml:space="preserve">${xmlEsc(v)}</t></is></c>`;
  }).join('')}</row>`).join('');
  const sheet=`<?xml version="1.0" encoding="UTF-8" standalone="yes"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetViews><sheetView workbookViewId="0"><pane ySplit="1" topLeftCell="A2" activePane="bottomLeft" state="frozen"/></sheetView></sheetViews><cols>${widths.map((w,i)=>`<col min="${i+1}" max="${i+1}" width="${w}" customWidth="1"/>`).join('')}</cols><sheetData>${rowXml}</sheetData><autoFilter ref="A1:G${Math.max(1,all.length)}"/></worksheet>`;
  const now=new Date().toISOString();
  return makeZip([
    ['[Content_Types].xml','<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/><Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/><Override PartName="/docProps/core.xml" ContentType="application/vnd.openxmlformats-package.core-properties+xml"/><Override PartName="/docProps/app.xml" ContentType="application/vnd.openxmlformats-officedocument.extended-properties+xml"/></Types>'],
    ['_rels/.rels','<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/><Relationship Id="rId2" Type="http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties" Target="docProps/core.xml"/><Relationship Id="rId3" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/extended-properties" Target="docProps/app.xml"/></Relationships>'],
    ['docProps/core.xml',`<?xml version="1.0" encoding="UTF-8" standalone="yes"?><cp:coreProperties xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/core-properties" xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:dcterms="http://purl.org/dc/terms/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"><dc:creator>Admin Desa</dc:creator><dc:title>Data Pelanggan</dc:title><dcterms:created xsi:type="dcterms:W3CDTF">${now}</dcterms:created></cp:coreProperties>`],
    ['docProps/app.xml','<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Properties xmlns="http://schemas.openxmlformats.org/officeDocument/2006/extended-properties"><Application>Admin Desa Offline</Application></Properties>'],
    ['xl/workbook.xml','<?xml version="1.0" encoding="UTF-8" standalone="yes"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="Data Pelanggan" sheetId="1" r:id="rId1"/></sheets></workbook>'],
    ['xl/_rels/workbook.xml.rels','<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/><Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>'],
    ['xl/styles.xml','<?xml version="1.0" encoding="UTF-8" standalone="yes"?><styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><fonts count="2"><font><sz val="11"/><name val="Calibri"/></font><font><b/><sz val="11"/><name val="Calibri"/></font></fonts><fills count="1"><fill><patternFill patternType="none"/></fill></fills><borders count="1"><border><left/><right/><top/><bottom/><diagonal/></border></borders><cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs><cellXfs count="3"><xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/><xf numFmtId="0" fontId="1" fillId="0" borderId="0" xfId="0" applyFont="1"/><xf numFmtId="3" fontId="0" fillId="0" borderId="0" xfId="0" applyNumberFormat="1"/></cellXfs></styleSheet>'],
    ['xl/worksheets/sheet1.xml',sheet]
  ]);
}
function exportExcel(){
  downloadBlob(buildCustomerXLSX(),'export-admin-desa-'+fileStamp()+'.xlsx');
  toast('File Excel .xlsx berhasil diekspor.');
}
function resetData(){showModal(`<div class="modal-icon" style="background:#ffe3e3;color:#e74b4b">!</div><h3>Reset Semua Data</h3><p>Semua data pelanggan dan transaksi yang pernah diinput akan dikosongkan. Profil aplikasi tetap disimpan.</p><div class="modal-actions"><button class="btn btn-secondary" onclick="closeModal()">Batal</button><button class="btn btn-danger" onclick="resetAllInputData()">Reset</button></div>`);}
function resetAllInputData(){
  DB.customers=[];
  DB.receipts=[];
  saveDB();
  closeModal();
  toast('Data pelanggan dan transaksi berhasil dikosongkan.');
  renderProfile();
}
