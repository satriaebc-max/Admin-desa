let currentRoute = "home";
let previousRoute = "home";

const screen = document.getElementById("screen");
const pageTitle = document.getElementById("pageTitle");
const backBtn = document.getElementById("backBtn");
const modalBackdrop = document.getElementById("modalBackdrop");
const modal = document.getElementById("modal");
const toastContainer = document.getElementById("toastContainer");

function navigate(route){
  if(currentRoute !== route) previousRoute = currentRoute;
  currentRoute = route;
  render();
  window.scrollTo({top:0,behavior:"smooth"});
}

function render(){
  const routes = {
    home: renderHome,
    customers: renderCustomers,
    add: renderAddCustomer,
    check: renderCheck,
    receipts: renderReceipts,
    receipt: renderReceiptDetail,
    profile: renderProfile
  };
  (routes[currentRoute] || renderHome)();
  document.querySelectorAll(".nav-item").forEach(b=>b.classList.toggle("active", b.dataset.route===currentRoute || (currentRoute==="add" && b.dataset.route==="customers")));
  backBtn.classList.toggle("hidden", !["add","check","receipt"].includes(currentRoute));
  pageTitle.textContent = ({
    home:"Admin Desa",customers:"Data Pelanggan",add:"Tambah Pelanggan",check:"Cek Tagihan",
    receipts:"Cetak Struk",receipt:"Detail Struk",profile:"Profil"
  })[currentRoute] || "Admin Desa";
  document.getElementById("greeting").textContent = currentRoute==="home" ? "Selamat Datang," : "Admin Desa";
}

function renderHome(){
  const total = DB.customers.reduce((s,c)=>s+Number(c.amount||0),0);
  const paid = DB.customers.filter(c=>c.status==="paid").reduce((s,c)=>s+Number(c.amount||0),0);
  const unpaid = total-paid;
  const pct = total ? (paid/total*100) : 0;
  screen.innerHTML = `<div class="page">
    <section class="hero-card">
      <div class="label">Total Tagihan</div>
      <div class="big-money">${rupiah(total)}</div>
      <div class="hero-sub">Total ${DB.customers.length} Pelanggan</div>
      <div class="hero-grid">
        <div class="hero-stat"><span class="label">Terkumpul</span><b class="green-text">${rupiah(paid)}</b><small>${pct.toFixed(2)}%</small></div>
        <div class="hero-stat"><span class="label">Sisa Tagihan</span><b class="blue-text">${rupiah(unpaid)}</b><small>${(100-pct).toFixed(2)}%</small></div>
      </div>
    </section>
    <div class="dashboard-grid">
      <button class="quick-card" onclick="navigate('customers')"><span class="quick-icon">☷</span><span><strong>Data</strong><small>Pelanggan</small></span></button>
      <button class="quick-card" onclick="navigate('check')"><span class="quick-icon">⌕</span><span><strong>Cek</strong><small>Tagihan</small></span></button>
      <button class="quick-card" onclick="navigate('receipts')"><span class="quick-icon">▤</span><span><strong>Cetak</strong><small>Struk</small></span></button>
      <button class="quick-card" onclick="openPaymentPicker()"><span class="quick-icon">Rp</span><span><strong>Pembayaran</strong><small>Konfirmasi</small></span></button>
    </div>
    <section class="section">
      <div class="section-title"><h3>Ringkasan Pembayaran</h3><button onclick="navigate('customers')">Lihat data</button></div>
      <div class="summary">
        <div class="donut" style="background:conic-gradient(var(--green) 0 ${pct}%,#e84d4d ${pct}% 100%)"><span>${pct.toFixed(2)}%<small>Terkumpul</small></span></div>
        <div class="legend">
          <div class="legend-row"><i class="dot"></i> Terbayar <b>${rupiah(paid)}</b></div>
          <div class="legend-row"><i class="dot red"></i> Belum Terbayar <b>${rupiah(unpaid)}</b></div>
        </div>
      </div>
    </section>
    <section class="section">
      <div class="section-title"><h3>Statistik</h3></div>
      <div class="stats">
        <div class="stat-box"><small>Total Pelanggan</small><b>${DB.customers.length}</b></div>
        <div class="stat-box"><small>Sudah Lunas</small><b>${DB.customers.filter(c=>c.status==="paid").length}</b></div>
        <div class="stat-box"><small>Belum Lunas</small><b>${DB.customers.filter(c=>c.status!=="paid").length}</b></div>
        <div class="stat-box"><small>Total Transaksi</small><b>${DB.receipts.length}</b></div>
      </div>
    </section>
  </div>`;
}

function showModal(html){ modal.innerHTML=html; modalBackdrop.classList.remove("hidden"); }
function closeModal(){ modalBackdrop.classList.add("hidden"); modal.innerHTML=""; }
modalBackdrop.addEventListener("click",e=>{if(e.target===modalBackdrop)closeModal()});

function toast(msg){
  const t=document.createElement("div"); t.className="toast"; t.textContent=msg; toastContainer.appendChild(t);
  setTimeout(()=>t.remove(),2600);
}

document.getElementById("fabBtn").onclick=()=>navigate("add");
document.getElementById("backBtn").onclick=()=>navigate(previousRoute==="add"||previousRoute==="check"||previousRoute==="receipt" ? "home" : previousRoute);
document.getElementById("quickPaymentBtn").onclick=()=>openPaymentPicker();
document.querySelectorAll(".nav-item").forEach(b=>b.onclick=()=>navigate(b.dataset.route));

document.getElementById("themeBtn").onclick=()=>{
  document.body.classList.toggle("dark");
  localStorage.setItem("adminDesaTheme",document.body.classList.contains("dark")?"dark":"light");
  document.getElementById("themeBtn").textContent=document.body.classList.contains("dark")?"☾":"☀";
};
if(localStorage.getItem("adminDesaTheme")==="dark"){document.body.classList.add("dark");document.getElementById("themeBtn").textContent="☾";}

render();
