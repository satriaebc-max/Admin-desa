function renderCustomers(){
  screen.innerHTML=`<div class="page">
    <section class="section" style="margin-top:0">
      <div class="section-title"><h3>Data Pelanggan</h3><div style="display:flex;gap:7px;align-items:center"><button class="bulk-btn" onclick="openBulkImport()" title="Tambah pelanggan massal">⇧ Massal</button><button onclick="navigate('add')">+ Tambah</button></div></div>
      <div class="stats">
        <div class="stat-box"><small>Total Pelanggan</small><b>${DB.customers.length}</b></div>
        <div class="stat-box"><small>Total Tagihan</small><b>${rupiah(DB.customers.reduce((s,c)=>s+Number(c.amount),0))}</b></div>
      </div>
    </section>
    <section class="section">
      <div class="search"><span>⌕</span><input id="customerSearch" placeholder="Cari nama / ID / alias / layanan..." oninput="filterCustomers()"></div>
      <div class="pill-tabs">
        <button class="active" data-filter="all" onclick="setCustomerFilter('all',this)">Semua</button>
        <button data-filter="paid" onclick="setCustomerFilter('paid',this)">Lunas</button>
        <button data-filter="unpaid" onclick="setCustomerFilter('unpaid',this)">Belum</button>
      </div>
      <div class="customer-list" id="customerList"></div>
    </section>
  </div>`;
  window.customerFilter="all"; drawCustomers();
}
window.customerFilter="all";
function setCustomerFilter(filter,el){window.customerFilter=filter;document.querySelectorAll(".pill-tabs button").forEach(x=>x.classList.remove("active"));el.classList.add("active");drawCustomers();}
function filterCustomers(){drawCustomers();}
function drawCustomers(){
  const q=(document.getElementById("customerSearch")?.value||"").toLowerCase();
  const list=DB.customers.filter(c=>(window.customerFilter==="all"||c.status===window.customerFilter) && `${c.name} ${c.meter} ${c.alias||""} ${serviceName(c)}`.toLowerCase().includes(q));
  const box=document.getElementById("customerList"); if(!box)return;
  if(!list.length){box.innerHTML=`<div class="empty"><b>Tidak ada pelanggan</b>Coba ubah kata kunci atau filter.</div>`;return;}
  box.innerHTML=list.map(c=>`<article class="customer-card">
    <div onclick="showCustomerDetail('${c.id}')" style="cursor:pointer">
      <div class="customer-name">${esc(c.name)}</div>
      <div class="customer-meta">${esc(serviceName(c))} · ${esc(idLabel(c))}: ${esc(c.meter)}${c.alias?`<br>Alias: ${esc(c.alias)}`:""}</div>
    </div>
    <div>
      <div class="amount">${rupiah(c.amount)}</div>
      <span class="status ${c.status==='paid'?'paid':'unpaid'}">${c.status==='paid'?'Lunas':'Belum'}</span>
      <button class="more" onclick="showCustomerMenu('${c.id}')">⋮</button>
    </div>
  </article>`).join("");
}
function showCustomerMenu(id){
  const c=DB.customers.find(x=>x.id===id); if(!c)return;
  showModal(`<div class="modal-icon">?</div><h3>${esc(c.name)}</h3><p>Pilih tindakan untuk pelanggan ini.</p>
    <div class="modal-actions" style="grid-template-columns:1fr">
      ${c.status!=="paid"?`<button class="btn btn-primary" onclick="closeModal();confirmPayment('${id}')">Tandai Lunas</button>`:`<button class="btn btn-secondary" onclick="closeModal();unpay('${id}')">Batalkan Status Lunas</button>`}
      <button class="btn btn-secondary" onclick="closeModal();editCustomer('${id}')">Edit Data</button>
      <button class="btn btn-danger" onclick="closeModal();deleteCustomer('${id}')">Hapus</button>
    </div>`);
}
function showCustomerDetail(id){
  const c=DB.customers.find(x=>x.id===id); if(!c)return;
  showModal(`<div class="modal-icon">♟</div><h3>Detail Pelanggan</h3>
    <div class="detail-table">
      <div class="detail-row"><span>Nama</span><b>:</b><span>${esc(c.name)}</span></div>
      <div class="detail-row"><span>Layanan</span><b>:</b><span>${esc(serviceName(c))}</span></div>
      <div class="detail-row"><span>${esc(idLabel(c))}</span><b>:</b><span>${esc(c.meter)}</span></div>
      ${c.alias?`<div class="detail-row"><span>Alias</span><b>:</b><span>${esc(c.alias)}</span></div>`:""}
      <div class="detail-row"><span>Nominal</span><b>:</b><span>${rupiah(c.amount)}</span></div>
      <div class="detail-row"><span>Status</span><b>:</b><span>${c.status==="paid"?"Lunas":"Belum"}</span></div>
    </div>
    <div class="modal-actions"><button class="btn btn-secondary" onclick="closeModal()">Tutup</button><button class="btn btn-primary" onclick="closeModal();${c.status==="paid"?`navigate('receipts')`:`confirmPayment('${id}')`}">${c.status==="paid"?"Lihat Struk":"Bayar"}</button></div>`);
}
function renderAddCustomer(editId=null){
  const c=editId?DB.customers.find(x=>x.id===editId):null;
  screen.innerHTML=`<div class="page">
    <section class="section" style="margin-top:0">
      <div class="section-title"><h3>${c?"Edit Pelanggan":"Tambah Pelanggan"}</h3></div>
      <div class="section" style="margin:0 0 12px;background:linear-gradient(135deg,#10a875,#13a16f);color:#fff;border:0">
        <div class="label">Total Data Pelanggan</div><div style="font-size:25px;font-weight:800;margin-top:3px">${DB.customers.length}</div><small>Orang</small>
      </div>
      <form id="customerForm">
        <div class="form-grid">
          <div class="field full"><label>Nama</label><input id="fName" required placeholder="Masukkan nama pelanggan" value="${esc(c?.name||"")}"></div>
          <div class="field full"><label>Jenis Tagihan / Layanan</label><select id="fService">${SERVICE_OPTIONS.map(x=>`<option ${serviceName(c)===x?"selected":""}>${esc(x)}</option>`).join("")}</select></div>
          <div class="field full"><label>ID Pelanggan</label><input id="fMeter" required placeholder="Masukkan ID pelanggan / nomor sambungan / identitas layanan" value="${esc(c?.meter||"")}"></div>
          <div class="field full"><label>Alias</label><input id="fAlias" placeholder="Masukkan alias / keterangan" value="${esc(c?.alias||"")}"></div>
          <div class="field full"><label>Nominal Tagihan</label><div class="input-money"><span>Rp</span><input id="fAmount" type="number" min="0" required placeholder="Masukkan nominal tagihan" value="${c?.amount||""}"></div></div>
        </div>
        <button class="btn btn-primary btn-full" type="submit">${c?"Simpan Perubahan":"Simpan Pelanggan"}</button>
      </form>
    </section>
  </div>`;
  document.getElementById("customerForm").onsubmit=e=>{
    e.preventDefault();
    const data={name:document.getElementById("fName").value.trim(),meter:document.getElementById("fMeter").value.trim(),alias:document.getElementById("fAlias").value.trim(),service:document.getElementById("fService").value||"Listrik",amount:Number(document.getElementById("fAmount").value)||0};
    if(!data.name||!data.meter)return toast("Nama dan ID Pelanggan wajib diisi.");
    if(c){Object.assign(c,data);toast("Data pelanggan diperbarui.");}
    else{DB.customers.push({id:uid("c"),...data,status:"unpaid",paidAt:null});toast("Pelanggan berhasil ditambahkan.");}
    saveDB();navigate("customers");
  };
}
function editCustomer(id){navigate("add");setTimeout(()=>renderAddCustomer(id),0);}
function deleteCustomer(id){
  const c=DB.customers.find(x=>x.id===id); if(!c)return;
  showModal(`<div class="modal-icon" style="background:#ffe3e3;color:#e74b4b">!</div><h3>Hapus Pelanggan</h3><p>Yakin ingin menghapus <b>${esc(c.name)}</b>? Data ini tidak bisa dipulihkan.</p><div class="modal-actions"><button class="btn btn-secondary" onclick="closeModal()">Batal</button><button class="btn btn-danger" onclick="DB.customers=DB.customers.filter(x=>x.id!=='${id}');saveDB();closeModal();toast('Pelanggan dihapus.');renderCustomers()">Hapus</button></div>`);
}
