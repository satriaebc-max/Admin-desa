# ADMIN DESA — Personal Offline v2

Aplikasi lokal/offline untuk data pelanggan, tagihan, pembayaran, struk, backup, dan import pelanggan massal. Tidak memakai Supabase/database online.

## Fitur baru v2
- Tombol **⇧ Massal** di halaman Data Pelanggan.
- Import pelanggan dari **Excel .xlsx** atau **JSON .json**.
- Preview sebelum import.
- Baris tidak valid ditampilkan.
- ID Pelanggan duplikat dilewati.
- Template JSON tersedia dari dialog import.
- Informasi developer di Profil: Anz-Media, Phone 081280416515, Email satria.ebc@gmail.com.
- Service worker/cache dinaikkan ke v2 agar file import terbaru ikut tercache.

## Format Excel
Header yang dikenali antara lain: Nama, ID Pelanggan, Alias, Nominal Tagihan, Status, Tanggal Lunas.

Contoh:
Nama | ID Pelanggan | Alias | Nominal Tagihan | Status | Tanggal Lunas
Budi Santoso | 12345678901 | Rumah Budi | 150000 | lunas | 2026-08-28
Siti Aminah | 12345678902 | Rumah Siti | 200000 | belum |

## Format JSON
Gunakan array objek, misalnya:
```json
[{"nama":"Budi Santoso","id_pelanggan":"12345678901","alias":"Rumah Budi","nominal_tagihan":150000,"status":"lunas","tanggal_lunas":"2026-08-28"}]
```

## Penting setelah update
Jika sebelumnya aplikasi pernah dibuka sebagai PWA, hapus shortcut/PWA lama atau lakukan reload sekali setelah membuka versi v2 supaya cache lama tidak dipakai. Untuk penggunaan file biasa, ekstrak ZIP baru ini ke folder baru lalu buka `index.html`.
